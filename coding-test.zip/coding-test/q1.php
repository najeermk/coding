
<?php
	
	$file= fopen("input.txt","r");

	$array= array(echo fread($file,filesize("input.txt")));

	$itemcount= array_count_values($array);

	print_r($itemcount);

	fclose($file);

?>