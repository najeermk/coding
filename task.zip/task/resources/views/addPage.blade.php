@extends('layouts.layout')
@section('content')

	<div>
		<form method="post" action="{{ route('createproduct') }}">
			<label>Name</label>
			<input type="text" name="item_name">
			<label>Description</label>
			<input type="text" name="item_desc">
			<label>Image</label>
			<input type="file" name="file_path_img">
			<label>Video</label>
			<input type="file" name="file_path_vid">
			<button type="submit">Upload</button>			
		</form>
	</div>

@endsection