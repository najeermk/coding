<!DOCTYPE html>
<html>
<head>
	<title>Task</title>
</head>
<body>
	<div>
		@yield('content')
	</div>
</body>
</html>