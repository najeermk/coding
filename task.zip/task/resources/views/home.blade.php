@extends('layouts.layout')
@section('content')

	<div>
		<a href="{{ route('addproduct') }}"><button type="button">Upload</button></a>
		<a href="{{ route('buyplan') }}"><button type="button">Buy Plan</button></a>
		@foreach ($products as product)
			<h3>{{ $product->item_name }}</h3>
			
			<p>{{ $product->item_description }}</p>
		@endforeach
	</div>

@endsection