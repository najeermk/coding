@extends('layouts.layout')
@section('content')
	
	<div>
		<form method="post" action="{{ route('create') }}">
			@csrf
			<label>Username</label>
			<input type="text" name="username">
			<label>Password</label>
			<input type="text" name="password">
			<label>Confirm Password</label>
			<input type="text" name="confirm">
			<button type="submit">Submit</button>			
		</form>
	</div>

@endsection