@extends('layouts.layout')
@section('content')

	<div>

			<input type="checkbox" name="planA" value="planA">
			<label for="planA">Plan A</label><br>
			<input type="checkbox" name="planB" value="planB">
			<label for="planB">Plan B</label><br>
			<input type="checkbox" name="planC" value="planC">
			<label for="planC">Plan C</label><br>
			<!-- <button type="submit">Buy</button> -->
			<a href="{{ route('home') }}"><button type="button">Return to Home</button></a>

	</div>

@endsection