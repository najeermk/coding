@extends('layouts.layout')
@section('content')
	
	<div>
		<form method="post" action="{{ route('loggedin') }}">
			@csrf
			<label>Username</label>
			<input type="text" name="username">
			<label>Password</label>
			<input type="text" name="password">
			<button type="submit">Submit</button>			
		</form>
	</div>

@endsection