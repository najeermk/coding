
<?php $__env->startSection('content'); ?>
	
	<div>
		<form method="post" action="<?php echo e(route('loggedin')); ?>">
			<?php echo csrf_field(); ?>
			<label>Username</label>
			<input type="text" name="username">
			<label>Password</label>
			<input type="text" name="password">
			<button type="submit">Submit</button>			
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\task\resources\views/login.blade.php ENDPATH**/ ?>