<!DOCTYPE html>
<html>
<head>
	<title>Task</title>
</head>
<body>
	<div>
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\task\resources\views/layouts/layout.blade.php ENDPATH**/ ?>