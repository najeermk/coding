<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ProductController::class,'Home'])->name('home');

Route::get('/register', [UserController::class,'RegisterPage'])->name('register');
Route::post('/create', [UserController::class,'Create'])->name('create');
Route::get('/loginpage', [UserController::class,'LoginPage'])->name('loginpage');
Route::post('/loggedin', [UserController::class,'Login'])->name('loggedin');

Route::get('/addproduct', [UserController::class,'addProduct'])->name('addproduct');
Route::post('/createproduct', [ProductController::class,'CreateProduct'])->name('createproduct');
Route::get('/buyplan', [ProductController::class,'BuyPlan'])->name('buyplan');
//Route::post('/plans', [ProductController::class,'Plans'])->name('plans');
