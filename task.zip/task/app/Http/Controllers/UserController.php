<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function RegisterPage()
    {
    	return view('register');
    }

    public function Create(Request $request)
    {
    	$validateData = $request->validate([
    		'password' => 'min:8|required_with:confirm|same:confirm',
    		'confirm' => 'min:8|same:password'
    	]);
    	if($validateData) {
    		$user = new User;
    		$user->username = $request->username;
    		$user->password = $request->password;
    		$user->save();
    	}

    	return redirect()->route('home');
    }


    public function LoginPage()
    {
    	return view('login');
    }

    public function Login(Request $request)
    {
    	$user = $request->only('username', 'password');
 
        if (Auth::attempt($user)) {
            return redirect()->route('home');
        } else {
        	return redirect()->route('loginpage')->with('username or password is incorrect');
        }
    }
}
