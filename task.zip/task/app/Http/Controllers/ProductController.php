<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{

	public function addProduct()
	{
		return view('addPage');
	}

    public function CreateProduct(Request $request)
    {

    	$product = new Product;
    	$product->item_name = $request->item_name;
    	$product->item_description = $request->item_desc;
    	$product->file_path_img = $request->file_path_img;
    	$product->file_path_vid = $request->file_path_vid;
    	$product->save();

    	return redirect()->route('home');
    }

    public function Home()
    {
    	
    	//$users = User::where();
    	$products = Product::all();


    	return view("home")->compact('products');
    }

    public function BuyPlan()
    {
    	return view('buyplan');
    }

    // public function Plans(Request $request)
    // {
    // 	$plan = $request->input('name');
    // }

}
